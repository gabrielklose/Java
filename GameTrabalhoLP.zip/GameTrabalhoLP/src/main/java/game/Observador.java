
package game;

/**
 *
 * @author felipe
 *  Você não precisa mexer nessa classe
 */
public interface Observador   {
    
    public void update(Observavel ob);    
}
