
package game;


public interface Observador   
{    
    public void update(Observavel ob);    
}
