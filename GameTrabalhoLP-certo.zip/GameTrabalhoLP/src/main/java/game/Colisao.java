
package game;


public class Colisao   implements Observador{
    @Override
    public void update(Observavel ob) {
    }
    
}
